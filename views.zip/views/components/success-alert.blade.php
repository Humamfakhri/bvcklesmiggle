<div class="myAlert transition-opacity duration-300 rounded fixed top-0 right-0 padding-container pt-5" role="alert">
    <div class="bg-green-100 rounded border border-green-400 text-green-700 px-4 py-3">
        <span class="block sm:inline">{{ $slot }}</span>
    </div>
</div>
