<x-layout>
  <main>
    
  </main>
</x-layout>