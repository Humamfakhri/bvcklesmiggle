<div class="myAlert transition-opacity duration-300 rounded fixed top-0 right-0 padding-container pt-5" role="alert">
    <div class="bg-red-100 rounded border border-red-400 text-red-700 px-4 py-3">
        {{-- <span class="block sm:inline">Berhasil</span> --}}
        <span class="block sm:inline">{{ $slot }}</span>
    </div>
</div>
