<footer class="max-container padding-container mb-3 lg:mb-0">
    <div class="py-1 border-t-2 border-gray-200 mt-5">
        <p class="text-end text-xs text-gray-200 font-segoe font-semibold">COPYRIGHT ©2024<br>BVCKLESMIGGLE, ALL
            RIGHT RESERVED</p>
    </div>
</footer>